const orb=document.getElementById('orb'),panel=document.getElementById('panel'),state=document.getElementById('state'),chat=document.getElementById('chat'),talk=document.getElementById('talk'),close=document.getElementById('close');
let recorder=null, chunks=[], history=[], busy=false;

function setState(s){orb.className=s;state.textContent={ready:'READY • TAP THE CORE TO SPEAK',listening:'LISTENING…',thinking:'THINKING…',speaking:'SPEAKING…',error:'ERROR'}[s]||s}
function add(t,c='j'){const d=document.createElement('div');d.className='m '+c;d.textContent=t;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function speak(t){if(!('speechSynthesis' in window)){setState('ready');return} setState('speaking');speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='en-US';u.rate=.95;u.pitch=.9;u.onend=()=>setState('ready');u.onerror=()=>setState('ready');speechSynthesis.speak(u)}
async function ask(text){if(!text)return;add(text,'u');setState('thinking');try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:history.slice(-10)})});const d=await r.json();if(!r.ok)throw Error(d.error||'AI request failed');history.push({role:'user',content:text},{role:'assistant',content:d.reply});add(d.reply);speak(d.reply)}catch(e){setState('error');add('JARVIS connection error: '+e.message);setTimeout(()=>setState('ready'),3000)}}
async function startRecording(){
 if(busy)return; busy=true;
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  chunks=[];
  const type=MediaRecorder.isTypeSupported('audio/webm;codecs=opus')?'audio/webm;codecs=opus':'audio/webm';
  recorder=new MediaRecorder(stream,{mimeType:type});
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=async()=>{stream.getTracks().forEach(t=>t.stop());await transcribe(new Blob(chunks,{type}));busy=false};
  recorder.start();setState('listening');talk.textContent='⏹️ Stop';
 }catch(e){busy=false;setState('error');add('Microphone access failed. Please allow microphone access for JARVIS in Safari.');setTimeout(()=>setState('ready'),3000)}
}
function stopRecording(){if(recorder&&recorder.state==='recording'){recorder.stop();talk.textContent='🎙️ Talk';setState('thinking')}}
async function transcribe(blob){
 try{
  const form=new FormData();form.append('audio',blob,'jarvis.webm');
  const r=await fetch('/api/voice',{method:'POST',body:form});const d=await r.json();
  if(!r.ok)throw Error(d.error||'Transcription failed');
  await ask(d.text);
 }catch(e){setState('error');add('Voice connection error: '+e.message);setTimeout(()=>setState('ready'),3000)}
}
orb.onclick=()=>{panel.classList.add('open');startRecording()};close.onclick=()=>panel.classList.remove('open');talk.onclick=()=>recorder?.state==='recording'?stopRecording():startRecording();
setState('ready');
