JARVIS Voice v4.
Replace app.js in the repo and add/replace api/chat.js, add api/voice.js, and replace package.json.
Keep index.html and manifest.webmanifest.
Keep OPENAI_API_KEY only in Vercel Environment Variables.
