export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const {message,history=[]}=req.body||{};
  if(!message)return res.status(400).json({error:"Missing message"});
  const input=[
   {role:"developer",content:"You are JARVIS, a calm, helpful, concise personal AI assistant. Your replies will be read aloud, so speak naturally and avoid long lists unless requested."},
   ...history.slice(-10).map(m=>({role:m.role==="assistant"?"assistant":"user",content:String(m.content||"")})),
   {role:"user",content:message}
  ];
  const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:"gpt-5.6",input})});
  const d=await r.json();if(!r.ok)return res.status(r.status).json({error:d?.error?.message||"AI request failed"});
  return res.status(200).json({reply:d.output_text||"I didn't get a response."});
 }catch(e){console.error(e);return res.status(500).json({error:"JARVIS server error"})}
}
