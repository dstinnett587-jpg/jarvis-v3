export const config={api:{bodyParser:false}};
export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const chunks=[];for await(const chunk of req)chunks.push(chunk);const body=Buffer.concat(chunks);
  const contentType=req.headers["content-type"]||"";
  if(!body.length)return res.status(400).json({error:"No audio received"});
  const boundaryMatch=contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if(!boundaryMatch)return res.status(400).json({error:"Audio upload format not recognized"});
  const boundary=Buffer.from("--"+(boundaryMatch[1]||boundaryMatch[2]));
  const end=Buffer.from("--"+(boundaryMatch[1]||boundaryMatch[2])+"--");
  const start=body.indexOf(boundary); const next=body.indexOf(boundary,start+boundary.length);
  const part=body.slice(start+boundary.length+2,next>0?next:body.length);
  const sep=Buffer.from("\r\n\r\n"); const headerEnd=part.indexOf(sep);
  if(headerEnd<0)return res.status(400).json({error:"Invalid audio form"});
  let audio=part.slice(headerEnd+4); if(audio.slice(-2).equals(Buffer.from("\r\n")))audio=audio.slice(0,-2);
  const form=new FormData();
  form.append("file",new Blob([audio],{type:"audio/webm"}),"jarvis.webm");
  form.append("model","gpt-4o-mini-transcribe");
  const r=await fetch("https://api.openai.com/v1/audio/transcriptions",{method:"POST",headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:form});
  const d=await r.json();if(!r.ok)return res.status(r.status).json({error:d?.error?.message||"Transcription failed"});
  return res.status(200).json({text:d.text||""});
 }catch(e){console.error(e);return res.status(500).json({error:"Voice server error"})}
}
